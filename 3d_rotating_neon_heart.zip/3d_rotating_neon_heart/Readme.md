# 3D Rotating Neon Heart Animation ❤️✨

A mesmerizing 3D rotating particle heart animation built using Python's built-in **Turtle** graphics and custom mathematical projection formulas.

## Creator
- **Developed by:** Codingwithvishesh

## Requirements

- Python 3.x (Turtle graphics comes pre-installed with Python)

## Folder Structure

```text
3d_rotating_neon_heart/
├── main.py
└── README.md